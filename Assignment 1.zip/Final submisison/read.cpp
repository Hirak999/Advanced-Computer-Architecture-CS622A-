#include <sys/types.h>
#include <sys/stat.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include<iostream>
using namespace std;


typedef struct trace {
    int n;
    char c[30];
} t;

static mode_t mode = 0777;
static const char* location = "traces";  // location in which trace files are available

static t traces[6] = {
    {2, "bzip2.log_l1misstrace"},
    {2, "gcc.log_l1misstrace"},
    {1, "gromacs.log_l1misstrace"},
    {1, "h264ref.log_l1misstrace"},
    {1, "hmmer.log_l1misstrace"},
    {2, "sphinx3.log_l1misstrace"},
};


int main(int argc, char **argv) {
    long long int count=0;
    char iord, type;
     char input[500], buffer[500], output[500];
    const char *folder = "output";
    unsigned pc;
    unsigned long long addr;
    struct stat sb;

    // Create a folder to store the processed traces
    if (stat(folder, &sb) || !S_ISDIR(sb.st_mode))
        mkdir(folder, mode);
    //else printf("output folder is already created\n");

    //converting to trace files of type '.out'
    for (int i = 0; i < 6; i++) {
        sprintf(output, "%s/%s.out", folder, traces[i].c);
        FILE *fout = fopen(output, "w");
        for (int j = 0; j < traces[i].n; j++) {
            sprintf(input, "%s/%s_%d", location, traces[i].c, j);
            FILE *fp = fopen(input, "rb");
            assert(fp != NULL);

            while (!feof(fp)) {
                fread(&iord, sizeof(char), 1, fp);
                fread(&type, sizeof(char), 1, fp);
                fread(&addr, sizeof(unsigned long long), 1, fp);
                fread(&pc, sizeof(unsigned), 1, fp);
                 
                 if(int(type)!=0)
			count++;
                                            
                // Process the entry
                sprintf(buffer, "%d %llu", type, addr);
                fprintf(fout, "%s\n", buffer);
            }
            fclose(fp);
            printf("Done reading file: %s\n", traces[i].c);
        }
        fclose(fout);
     
    }
    return 0;
}
