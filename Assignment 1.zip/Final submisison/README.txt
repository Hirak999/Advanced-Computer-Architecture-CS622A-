------- INDIAN INSTITUTE OF TECHNOLOGY KANPUR ----------
------- Department of Computer Science and Engineering ----------
------- CS 622A Semester 2020–2021-I: Assignment 1 -----------
------- Multi Level Cache Simulator ----------
Work Done By ---> MAYANK BANSAL (Roll- 20111032) and HIRAK MONDAL (Roll- 20111022)
Instructor ----> Dr. MAINAK CHAUDHURY



----- COMPILATION INSTRUCTIONS -------------

1. First we need to paste all the TRACE files inside the provided 'traces' directory

2. U need to set your working directory to the location where the 'read.cpp' file is saved. Use the cd command followed by the file path in linux based environment
   
   Command--> cd 'path where the read.cpp file is saved' {without ''}


3. Then run the 'read.cpp' file using the commands
  
   compilation-->  g++ read.cpp
   To run     -->  ./a.out
   
4. U need to set your working directory to the location inside the 'ouput' directory since that is where INCLUSIVE.py, EXCLUSIVE.py, NINE.py files are saved
   
   Command--> cd 'path  inside the 'output directory' where INCLUSIVE.py, EXCLUSIVE.py, NINE.py file is saved' {without ''}


5.  To run INCLUSIVE file use---> python INCLUSIVE.py
     
    To run EXCLUSIVE file use----> python EXCLUSIVE.py
     
    To run NINE file use python----> NINE.py
    
6. U need to set your working directory to the location inside the 'traces' directory since that is where Problem2.cpp files are saved
   
   Command--> cd 'path inside the 'traces' directory where 'Problem2.cpp' file is saved' {without ''}
   
7. Then run the 'Problem2.cpp' file using the commands
  
   compilation-->  g++ Problem2.cpp
   To run     -->  ./a.out
