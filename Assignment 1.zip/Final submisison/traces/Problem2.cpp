#include <stdio.h>
#include<math.h>      
#include <stdlib.h>  
#include<cassert>
#include<list>
#include<string.h>
#include<iostream>
#include<fstream>
#include <bits/stdc++.h> 
#include <chrono>
#include <algorithm>
#include <sys/time.h>
#define ll long long int
using namespace std;
using namespace std::chrono;

typedef struct trace {
    int n;
    char c[100];
} traces;


static traces t[6] = {
    {2, "bzip2.log_l1misstrace"},
    {2, "gcc.log_l1misstrace"},
    {1, "gromacs.log_l1misstrace"},
    {1, "h264ref.log_l1misstrace"},
    {1, "hmmer.log_l1misstrace"},
    {2, "sphinx3.log_l1misstrace"},
};



int main(/*int argc, char const *argv[]*/)
{

auto startTime1 = high_resolution_clock::now();
for(int i=0;i<6;i++)
{	

	
	list <int> l2[1024];  //list 2 for maintaining 1024 dll, corresponding to each set


	//since L3 cache is fully associative no need to create seperate sets for it
	list <int> l3;

	
        int hit=0,miss=0,cm=0,cap=0; //miss=total miss  and cm=cold miss
        ll block2,set2,block3;  //block 2 and block 3 is same since block size is same in both

	char iord; char type; unsigned long long addr; unsigned pc;
	char input_name[30];
	unordered_map<int, bool> um; 
 
	int numtraces = t[i].n;
	for (int k=0; k<numtraces; k++) 
	{
      		sprintf(input_name, "%s_%d", t[i].c, k);
      		FILE *fp = fopen(input_name, "rb");
      		assert(fp != NULL);
      		while (!feof(fp)) 
      		{
        		 fread(&iord, sizeof(char), 1, fp);
        		 fread(&type, sizeof(char), 1, fp);
         		 fread(&addr, sizeof(unsigned long long), 1, fp);
        		 fread(&pc, sizeof(unsigned), 1, fp);
        		 
        		/*
        		int a = type;
			string str  = std::to_string(a);
 			*/			
                         
                         //if t==1 then only its a cache miss, 
                         if(type!='0')
                         {
                                 //for l2 cache
                                 
                         	block2=floor(addr/64); //the block in which the address will be mapped
                             	set2= floor(block2%1024);  //the set in which the address will be mapped
                							
  				
  				// Now we will check if the block is present in the set2 of the L2 cache or not
  				
  				  list<int>::iterator f= find(l2[set2].begin(), l2[set2].end(), block2);
  				  
  				    if (f != l2[set2].end()) //i.e. the block is found inside the set i.e. l2 hit
    				 	{ 
        					l2[set2].erase(f);
    	  					l2[set2].push_back(block2);  //maintaining the LRU
    	  
    					} 
    				    else //i.e. the block is not found inside the set
    				    {
        					 
        					 //we need to see in the L3 cache now.
        					 
        					 list<int>::iterator f3= find(l3.begin(), l3.end(), block2);
        				          
        				          if (f3 != l3.end()) // the block is found inside L3 cache i.e. L3 hit
    				 		  { 
        						l3.erase(f3);
    	  						l3.push_back(block2);
    	  						
    	  						
    	  						//and then insert it to L2
    	  						
    	  						if(l2[set2].size() < 8) //which means that the set is NOT full
    				      			{
    				         		//then add the block at the last
    				         		l2[set2].push_back(block2);
				      			}

    				      			if(l2[set2].size() >= 8) //which means that the set is full
    				      			{
    				         		//delete the first element, which is the LRU
    				           		l2[set2].pop_front();
    				           
    				          		//Then add the block at the last
    				            		l2[set2].push_back(block2);
				      			}
    	  						
    	  						
    	  						
    						  }
    						    	
    						  else  //i.e. L3 miss
    						  {
    						     
    						 
    						     		  if(um[block2]==true) //Not cold miss
    						     		 {
    						     		        // we need to pop the first lru block, and also delete it from l2 as well
    						     		        ll front_element=l3.front();
    						     		        ll set=floor(front_element%1024);
    						     		        list<int>::iterator f4= find(l2[set].begin(), l2[set].end(), front_element);
    						     		         
    						     		        if (f4 != l2[set].end()) //i.e. the block is found inside the set
    				 					{ 
        									l2[set].erase(f4);
        									
    									} 
    						     		         
    						     		        //popping the first lru block from l3 cache 
    						     		 	l3.pop_front();
    						     		 	
    						     		 	//and inserting the new block
    				            				l3.push_back(block2);
    				            				
    				            				
    				            				           
    	  						//and then insert it to L2
    	  						
    	  						if(l2[set2].size() < 8) //which means that the set is NOT full
    				      			{
    				         		//then add the block at the last
    				         		l2[set2].push_back(block2);
				      			}

    				      			if(l2[set2].size() >= 8) //which means that the set is full
    				      			{
    				         		//delete the first element, which is the LRU
    				           		l2[set2].pop_front();
    				           
    				          		//Then add the block at the last
    				            		l2[set2].push_back(block2);
				      			}
    	  						
    				            				
    				            				
    				            				//so the total miss increases, but not the cold miss
    				            				miss++;
    				            				
    						     		 }
    						     		 else
    						     		 {
    						     		 	//first update the hashmap and increase the cold miss count
    						     		 	um[block2] = true; 
    						     		 	cm++;
    						     		 	miss++;
    						     		 	
    						     		 	if(l3.size()<pow(2,15))
    						     		 	{
    						     		 	l3.push_back(block2);
    						     		 	
    						     		 	//and then insert it to L2
    	  						
    	  						if(l2[set2].size() < 8) //which means that the set is NOT full
    				      			{
    				         		//then add the block at the last
    				         		l2[set2].push_back(block2);
				      			}

    				      			if(l2[set2].size() == 8) //which means that the set is full
    				      			{
    				         		//delete the first element, which is the LRU
    				           		l2[set2].pop_front();
    				           
    				          		//Then add the block at the last
    				            		l2[set2].push_back(block2);
				      			}
    	  						
    						     		 	
                                                                          }
                                                                          
                                                                          else{
    						     		 	
    						     		 	
    						     		 	// we need to pop the first lru block, and also delete it from l2 as well
    						     		        ll front_element=l3.front();
    						     		        ll set=floor(front_element%1024);
    						     		        list<int>::iterator f4= find(l2[set].begin(), l2[set].end(), front_element);
    						     		         
    						     		        if (f4 != l2[set].end()) //i.e. the block is found inside the set
    				 					{ 
        									l2[set].erase(f4);
    									} 
    						     		         
    						     		        //popping the first lru block from l3 cache 
    						     		 	l3.pop_front();
    				            				l3.push_back(block2);
    				            				
    				            				                                                                                
    	  						//and then insert it to L2
    	  						
    	  						if(l2[set2].size() < 8) //which means that the set is NOT full
    				      			{
    				         		//then add the block at the last
    				         		l2[set2].push_back(block2);
				      			}

    				      			if(l2[set2].size() == 8) //which means that the set is full
    				      			{
    				         		//delete the first element, which is the LRU
    				           		l2[set2].pop_front();
                                                         
                                                         //Then add the block at the last. 
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
    				            		l2[set2].push_back(block2);
				      			}
    	  						
    				            		}		
    						     		 }
    						     
    						     
    						     
    						  }
    						   
        					 
          			    }
                         	
                         }    
                         
      		}
      	
          
           	 
      		fclose(fp);
     
	} //this is where the k loop ends
	
	auto stopTime1 = high_resolution_clock::now();

	auto duration1 = duration_cast<microseconds>(stopTime1 - startTime1);
    
	cout << "Minutes: " << duration1.count()/60000000 << endl;
	
	cout<< "cold misses for "<<input_name<<" is: "<< cm<<endl;
	cout<< "capacity misses for gromacs "<<input_name<<" is : "<<miss-cm<<endl; 
	
	
	
}

return 0;

}
